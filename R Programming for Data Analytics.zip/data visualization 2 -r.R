#shows the mpg dataset
View(mpg)
#shows to plot the graph
plot<-ggplot(mpg,aes(x=factor(cyl),y=displ,fill=factor(cyl)))
#shows box plot. the upper layer is 75% quantile,middle line 50% quantile,lower layer 25% quantile,the box plot upper and lower line shows amx and min & the dotted points are outliers
plot+geom_boxplot()
#shows violin plots.it is a combination of box plot and density plot. middle cure is median,the upper layer is density plot,the viloin shape is violin plot
plot+geom_violin()
#shows corrplots.correlation plots which gives quick summary of data. the data should be numberic wrt data we have chosen mtcars
corrplot(cor(mtcars))
#shows the shape of the correlation matrix of our choice
corrplot(cor(mtcars),method = 'square')
corrplot(cor(mtcars),method='number')
#shows the no duplication of data
corrplot(cor(mtcars),method = 'number',type ='upper' )
#shows the corrgram which is also a similar graph
corrgram(cor(mtcars))
