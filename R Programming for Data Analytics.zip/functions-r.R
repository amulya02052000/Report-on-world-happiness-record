#showing how to create a function with argument passing
check<-function(x)
{
  print(sprintf("hello %s",x))
}
check("i am amulya")

clean<-function(y)
{
  print(sprintf("hello %d",y))
}
clean(10)
#showing how to create a function with two arguments passing
check<-function(x,y)
{
  print(sprintf("hello %s %s",x,y))
}
check("i am","amulya")
check(x="i am",y="amulya")
check(y="amulya",x="i am")
#showing do call function
mats<-function(x,func=mean)
{
  do.call(func,args = list(x))
}
mats(1:10)
mats(1:10,sum)
mats(1:10,sd)
mats(1:10,range)
mats(1:10,mode)
mats(1:10,median)
