#shows datasets
data()
View(Titanic)
#create data sets
Students<-c("girisha","amulya","bhanu","lakshmi")
weight<-c("30","86","90","46")
gender<-c("F","F","M","F")
age<-c("10","20","50","47")
#create a data frame
df<-data.frame(Students,weight,gender,age)
View(df)
#showing no. of rows in df and titanic
nrow(df)
nrow(Titanic)
#showing no. of columns in df and titanic
ncol(df)
ncol(Titanic)
#showing dimension in df and titanic
dim(Titanic)
dim(df)
#showing summary in df and titanic
summary(df)
summary(Titanic)
#showing first few elements in df and titanic
head(Titanic)
head(df)
#showing last few elements in df and titanic
tail(Titanic)
tail(df)
#showing structure of df and titanic
str(Titanic)
str(df)
#showing particular data set access from df
df$Students
df[["Students"]]
#showing access of particular dat from df and titanic
Titanic[1,1,2,1]
df[1,3]
#showing access of particular column in df and titanic
Titanic[,,,2]
df[,3]
#showing access of expect the particular column in df and titanic
Titanic[,,,-2]
df[,-3]
#showing particular data from row to row in df and titanic
Titanic[1:4,,,]
df[2:4,]
#showing how to call a particular column by column name for df and titanic
#Titanic[,c("Sex"),c("Age"),c("Survived")]
df[,c("Students")]
#showing subset function in df
subset(df,subset = Gender=="M")
weight.ordered<-order(df["weight"])
df[weight.ordered,]
#showind drop funtion with true and false
df[,2,drop=FALSE]
df[,2,drop=TRUE]
df[,3,drop=TRUE]
#showing the if statement is true or not
check<-2
if(check==2)
{
  print("the checked condition is true")
  print("hello!Amulya")
}
if(check==0)
{
  print("the checked condition is false")
  print("the output is not represented in console")
}
#showing the if else condition is true or not
check<-1
ifelse(check==1,"True","False")
    #another way to represent if else condition
value<-c(1,2,3,1,2,3,1,2,3)
ifelse(value==1,"True","False")
    #another way to show if else by multiplying 4 for true and 5 for false
ifelse(value==1,4*value,5*value)
#showing switch condition 
val<-function(x)
  switch(x,"a"="apple","b"="ball","not in the condition mentioned")
    #val("enter the case") will gives the ouput
#showing if else if condition is true or not
value<-1
if (value<2) {
  print('Not enough for today')
} else if (value > 2  &value<6) {
  print('Average day')
} else {
  print('What a great day!')
}
#showing for loop 
for (i in 1:5)
  print(i)
print(1:5)
#showing while loop
val<-1
while(val<5)
{
  print(val)
  val<-val+1
}
val<-13
while(val<20)
{
  print(val)
  val<-val+1
}
#showing next statement
for(i in 1:10)
{
  if(i==2)
  {
    next
  }
  print("value of i")
  print(i)
}
#showing break statement
for(i in 1:10)
{
  if(i==9)
  {
    break
  }
  print(i)
}
