#showing simple matrix form
c<-1:10
b<-5:14

matrix(b)
matrix(c)
#showing nrow and ncol in matrix
a<-matrix(c,nrow = 5)
d<-matrix(b,nrow=5)
#showing addition,multiplication,division and subtraction in matrix
z<-a+d
z
x<-a-d
x
a*d
a%%d

#showing nrow,ncol and dimension of the matrix
C<-matrix(c,nrow=10)
nrow(C)
B<-matrix(b,nrow=10)
nrow(B)
ncol(C)
ncol(B)

dim(C)
dim(B)
#showing how to name the matrices
z<-a*d
z
rownames(z)<-c("first","second","third","fourth","fifth")
colnames(z)<-c("first","second")
z#shows the name on the rows and cols
#showing byrow when byrow is true or not
c<-matrix(1:30,byrow = F,nrow = 5)
c
c<-matrix(1:30,byrow = T,nrow=5)
c
#showing fetched matrix elements wrt element given
c[2,3]
c[4,5]
c[5,6]
c[2,]
c[,3]
c[4,]
c[,5]
c[1:5,6]
c[1:3,3:5]
#showing the cbind for a data frame
a<-1:5
b<-31:35
cbind(a,b)
cbind(z,x)
#showing transpose of a matrix
z
t(z)
#showing sum of rows and cols
rowSums(z)
colSums(z)
#showing mean of rows and cols
mean(z)
rowMeans(z)
colMeans(z)
