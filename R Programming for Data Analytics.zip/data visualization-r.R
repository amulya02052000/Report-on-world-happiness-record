#showing import of packages
library(dplyr)
install.packages("ggplot2")
library(ggplot2)
#showing import of dataset
dataset<-read.csv("C:/Users/Amulya/Desktop/data analysis-r(skyfi labs)/diamonds.csv")
View(dataset)
#showing dataset performed for 10% of the whole dataset 
db<-sample_frac(dataset,0.1)
#showing how to plot ggplot with this 10% of dataset.showing the plot as histogram
plot<-ggplot(db,aes(x=price))#x-axis as price as continous variable
plot+geom_histogram(binwidth = 600)#600 binwidth is mandatory
#showing the color change of the graph
plot+geom_histogram(binwidth = 600,fill="Orange")
#showing the 7 layers of the graph
#a.continous data
#1.data
ggplot(db)
View(db)
#2.aesthetics & #3.geometrics wrt adding borders to the plot,filling the color of graph,alligning the color for the specific parameter
plot+geom_histogram(binwidth = 600,aes(fill=cut))
plot+geom_histogram(binwidth = 600,aes(fill=cut),color="Black")
plot+geom_histogram(binwidth = 600,aes(fill=clarity))
plot+geom_freqpoly(binwidth=600)
plot+geom_freqpoly(binwidth = 600,aes(color=cut))
plot+geom_freqpoly(binwidth = 600,aes(color=clarity))
plot+geom_dotplot(binwidth = 600,aes(fill=cut))
plot+geom_boxplot(binwidth = 600,aes(fill=cut))
plot+geom_bar(binwidth = 600,aes(fill=cut))
plot+geom_area(stat = "bin")
plot+geom_area(stat = "bin",aes(color=cut))
plot+geom_area(stat = "bin",aes(fill=cut))
plot+geom_density(aes(color=clarity))
plot+geom_density(aes(fill=cut))
plot+geom_density(aes(fill=cut),alpha=.3)#shows the hidden layers in the graph
plot+geom_density(aes(fill=cut),alpha=.3,size=3)#shows the thickness of the size

#b.discrete data on one variable
#1.plot bar graph wrt clarity on x-axis
plot<-ggplot(db,aes(x=clarity))
plot+geom_bar()
plot+geom_bar(aes(fill=cut),color=" Dark Green")#adds border and divides wrt the argument provides
plot+geom_bar(aes(fill=cut),color=" Dark Green",position = "fill")#shows the percentage for each part filled for the graph
plot+geom_bar(aes(fill=cut),color=" Dark Green",position=position_fill(reverse = TRUE))
plot+geom_bar(aes(fill=cut),color="Black",position="dodge")#shows clearly about the bar graph wrt each part
plot+geom_bar(aes(fill=cut),color="Black",position="stack")#shows clearly stack up of the graph
plot+geom_bar(aes(color=color),fill=NA,position = "Identity")#shows the graph filled without color
#c.discrete data of one variable x and continous data on y
plot<-ggplot(db,aes(cut,fill=clarity))
plot+geom_bar()
plot+geom_bar(position = "dodge")
plot+geom_bar(position = "fill")
plot+geom_bar(position = "stack")
plot+geom_bar()+coord_flip()#shows the graph from left side
plot+geom_bar()+coord_polar()#shows the graph as per coordinates as pie chart
plot+geom_bar(position = "stack")+ggtitle("cut representation wrt clarity")#shows the title for the graph
plot+geom_bar(position = "stack")+ggtitle("cut representation wrt clarity")+xlab("cut")+ylab("count")#shows the graph wrt cut v/s count
plot+geom_bar(position = "stack")+labs(title="classification",x="cut",y="count")#shows the "labs" under one place
  #showing the facets 
  plot+geom_bar(position = "dodge")+facet_grid(.~cut)
  plot+geom_bar(position = "dodge")+facet_wrap(.~cut)  
#d. continous data on two variables(x & y)
#using mtcars dataset for this continous data
View(mtcars)
plot<-ggplot(mtcars,aes(wt,mpg,label=rownames(mtcars)))#shows a graph wrt wt v/s mpg
plot+geom_text()#shows the graph in text form
plot+geom_label()#shows the graph in labels
plot+geom_label(aes(color=cyl))
factor(mtcars$cyl)#shows the levels of cyl wrt dataset cars using factor function
plot+geom_label(aes(color=factor(cyl)))#shows the graph wrt the cyl levels excluding the unwanted levels from the graph
plot+geom_point(aes(color=factor(cyl)))#shows the graph in points
plot+geom_point(aes(size=factor(cyl)))#shows the size of the points wrt cyl
plot+geom_point(aes(size=factor(cyl),alpha=0.5))#shows the overlapping of the points
plot+geom_point(aes(shape=factor(cyl)))#shows the shape of the graph levels wrt cyl
plot+geom_point(aes(shape=factor(cyl),size=3))#shows the increase of size wrt cyl levels
plot+geom_smooth()#shows the linear regression graph
plot+geom_smooth()+geom_point()#shows the points on the smooth graph
plot+geom_smooth(method = 'lm')+geom_point()#shows the linear graph 
plot+geom_quantile()+geom_point()#shows the quantile graph with 3 lines, 1st line 75% quantile, 2nd line(middle line) 50% quantile, 3rd line 25% quantile

