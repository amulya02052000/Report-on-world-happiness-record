#installing dplyr package
install.packages('dplyr')
#calling the package
library(dplyr)
library(stats)
#calling a data set called notebook.csv
ds<-read.csv("C:/Users/Amulya/Desktop/amulya/diamonds.csv")
#viewing the dataset
View(ds)
#showing head,tail,nrow,ncol,dim,summary,str of the dataset\
head(ds)
tail(ds)
nrow(ds)
ncol(ds)
dim(ds)
summary(ds)
str(ds)
#showing dplyr functions:
  #1.filter function
  head(filter(ds,carat>0.2,cut == "Premium"))
  head(filter(ds,carat>0.2,color=="E"))  
  tail(filter(ds,carat>0.7,color == "D"))    
  #2.slice function
  read<-slice(ds,1:10)
  View(read)  
  #3.arrange function
  head(arrange(ds,carat,cut,clarity,table))#arranges the data set asper the parameters are set
  #4.rename function
  head(rename(ds,idno=X))
  #5.mutate function.creating a new column with the addition into dataset without hindering the dataset and its parameters. It actually creates a new column name 
  change<-mutate(ds,initial_Price=price*2)
  View(change)  
  #6.transmute function.creating a new row with addition into data set without any changes in dataset.
  change<-transmute(ds,volumeOfdiamond=x*y*z)
  View(change)
  #7.summarise function. It gives min,max,mean,median,etc
  chance<-summarise(ds,avgprice=mean(price),maxcarat=max(carat),mindepth=min(depth),halfprice=median(price))
  View(chance)  
  #8.distinct function
  charve<-distinct(select(ds,cut,color))
  View(charve)  
  c<-distinct(select(ds,cut))
  View(c)
  c<-distinct(select(ds,color))
  View(c)
  #9.sample n function
  sample_n(ds,10)
  #10.sample frac function
  sample_frac(ds,0.02)
  #11.add row in existing dataset function
  c<-tail(add_row(ds,X=53941,carat=0.25,cut="Premium",color="F",clarity="vs2",depth=63.2,table=62.4,price=3757,x=5.2,y=5.72,z=3.85))
  View(c)  
  View(ds)
  