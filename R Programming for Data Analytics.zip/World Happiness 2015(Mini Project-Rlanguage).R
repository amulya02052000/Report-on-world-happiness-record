#World Happiness Data

#Data Manipulation of data
library(dplyr)
data<-read.csv("C:/Users/Amulya/Desktop/data analysis-r(skyfi labs)/world-happiness-data.csv")
View(data)

#remove the standard error data from the dataset
data<-data[,-5]
View(data)

#view the regions in the dataset
distinct(data,Region)


#create a new column continent to check which country falls in which continent
data$Continent<-NA

#create for every region for continent
data$Continent[which(data$Region %in% c("Australia and New Zealand"))]<-"Australia"
data$Continent[which(data$Region %in% c("North America"))]<-"America"
data$Continent[which(data$Region %in% c("Southern Asia","Eastern Asia","Southeastern Asia"))]<-"Asia"
data$Continent[which(data$Region %in% c("Western Europe","Central and Eastern Europe"))]<-"Europe"
data$Continent[which(data$Region %in% c("Sub-Saharan Africa","Middle East and Northern Africa"))]<-"Africa"
data$Continent[which(data$Region %in% c("Latin America and Caribbean"))]<-"South America"


#calculate the mean of the data wrt continents
hp<-aggregate(data[4:11],list(data$Continent),mean)# when aggregate mean is calculated happiest countries are australia,america & europe whereas africa and asia are least happy
View(hp)


#Visualization Process
library(ggplot2)
library(corrgram)
library(corrplot)


#summary of data
summary(data)


#top and bottom  10 countries of data
View(head(data,10))
View(tail(data,10))


#we will view hp dataset mean of all numeric data of all continents
ggplot(hp,aes(x=Group.1,y=Happiness.Score,fill=Group.1))+geom_bar(stat = "identity")+ggtitle("Continent V/S Happiness Score")+xlab("Continent")+ylab("Happiness Score")


#lets correlate the data
col<-sapply(data,is.numeric)
cor.data<-cor(data[,col])
corrplot(cor.data,method="square",type="upper")
#to see maximum correlation
corrplot(cor.data,method = "number",type="upper")
#conclusion of corrplot: the happiness rank is always inversely proportional to all the variables.As the score of happiness decreases all the pararmeters related to country improves.So doing correlation we shouldnt include happiness rank.The shades of blue give high correlation which are GDP,Family,Health life expectancy,Dystopia Residual,Freedom
#the strongest correlation is between GDP and health life expectancy


#create box plots wrt region wise
box<-ggplot(data,aes(x=Region,y=Happiness.Score,color=Region))
box+geom_boxplot()+geom_jitter(aes(color=Country),size=1.0)+ggtitle("Happiness Score for Regions and Countries")+coord_flip()+theme(legend.position = "none")


#create boxplot for continents
boxp<-ggplot(data,aes(x=Continent,y=Happiness.Score,color=Continent))
boxp+geom_boxplot()+ggtitle("Happiness Score for Continents")


#Regression for all continents
#for health life expectancy
ggplot(data,aes(x=Health..Life.Expectancy.,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for life expectancy")

#for economia gdp per capita
ggplot(data,aes(x=Economy..GDP.per.Capita.,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for Economy per Capita")

#for freedom
ggplot(data,aes(x=Freedom,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for Freedom")

#for family
ggplot(data,aes(x=Family,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for family")

#for trust in government
ggplot(data,aes(x=Trust..Government.Corruption.,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for trust in govt")

#for Generosity
ggplot(data,aes(x=Generosity,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for generosity")

#for Dystopia Residual
ggplot(data,aes(x=Dystopia.Residual,y=Happiness.Score))+geom_point(aes(color=Continent),size=3,alpha=0.8)+geom_smooth(aes(color=Continent,fill=Continent),method="lm",fullrange=T)+facet_wrap(~Continent)+theme_bw()+ggtitle("Scatter Plot for dystopia residual")

#conclusion of happiness score region wise:
#happiest countries: North America-2 countries,Australia and New Zealand-2 countries,Western Europe-21 countries
#unhappiest country: Sub-Saharan Africa-40 countries
#by using box plot we can conclude europe is happiest continent whereas africa is unhappiest continent
#by using regression concept w.r.t health life expectancy we can say europe and south america have highest correlation and africa with neutral correlation.
#For GDP the South America has highest correlation and africa with least correlation.
#But the data is not comparable to North America and Australia
#For Freedom the europe and south america have positive correlation whereas asia with poor correlation




#as we can see that australia and new zealand,western europe,north america are happiest region,whereas every other are neutral happy except sub saharan africa which is unhappiest
#create a classition of data based on happiest,neutral and least happy regions of data
data$happinessmeter<-NA
data$happinessmeter[which(data$Region %in% c("Australia and New Zealand","North America","Western Europe"))]<-"HAPPIEST"
data$happinessmeter[which(data$Region %in% c("Middle East and Northern Africa","South America","Central and Eastern Europe","Middle East and Northern Africa","Latin America and Caribbean","Eastern Asia","Southern Asia","Southeastern Asia"))]<-"NEUTRAL HAPPY"
data$happinessmeter[which(data$Region %in% c("Sub-Saharan Africa"))]<-"UNHAPPIEST"


#create regression lines for all the three regions(happy,unhappy,neutral)
ggplot(data,aes(x=Health..Life.Expectancy.,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for life expectancy")

#for economy
ggplot(data,aes(x=Economy..GDP.per.Capita.,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for Economy per capita")

#for family
ggplot(data,aes(x=Family,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for family")

#for generosity
ggplot(data,aes(x=Generosity,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for generosity")

#for trust government corruption
ggplot(data,aes(x=Trust..Government.Corruption.,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for trust in govt")

#for dystopia residual
ggplot(data,aes(x=Dystopia.Residual,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for dystopia residual")

#freedom
ggplot(data,aes(x=Freedom,y=Happiness.Score))+geom_point(aes(color=happinessmeter),size=3,alpha=0.8)+geom_smooth(aes(color=happinessmeter,fill=happinessmeter),method="lm",fullrange=T)+facet_wrap(~happinessmeter)+theme_bw()+ggtitle("Scatter Plot for freedom")


#conclusion for regression of happiness meter:
#for health and life exxpectancy: the unhappiest has low correlation and happiest data is not related to health.
#for Economy.GDP per capita: the happiest have high correaltion and unhappiest have low correlation
#for generosity: As it is neutral in happinessmeter it is declared as less generous compare to happiest and unhappiest regions.



#plot gdp and health expectancy on world map
library(rworldmap)

#create a data frame
db<-data.frame(Country=data$Country,Value=data$Economy..GDP.per.Capita.)
#join the data
db1<-joinCountryData2Map(db,joinCode = "NAME",nameJoinColumn = "Country")
#map the data
mapCountryData(db1,nameColumnToPlot = "Value",mapTitle = "World Map for GDP 2015",colourPalette ="terrain")

#for health life expectancy
db<-data.frame(Country=data$Country,Value=data$Health..Life.Expectancy.)
#join the data
db1<-joinCountryData2Map(db,joinCode = "NAME",nameJoinColumn = "Country")
#map the data
mapCountryData(db1,nameColumnToPlot = "Value",mapTitle = "World Map for Health Life Expectancy 2015",colourPalette ="terrain")


#conclusion for mapdata
#represents in a map with terrain colors,the green color in map has more Economy GDP per Capita whereas grey color shows least Economy GDP per Capita.The nations which are in white color are not included in data set.
