#Project on data visulization on world happiness data

#step 1: data manipulation 


#install dplyr package
library(dplyr)

#read the dataset into db
db<-read.csv('C:/Users/Amulya/Desktop/data analysis-r(skyfi labs)/world-happiness-data.csv')

#view the dataset
View(db)

#consider the data to be error free
#to make error free data make standard error apart from the all data
db<-db[,-5]

#to check the regions in the dataset
distinct(db,Region)

#classifying the data wrt the continents v/s regions
#to make that regions check in coninent 
db$continent<-NA

#to make the region fall into the continent 
  #1.Australia
  db$continent[db$Region %in% c("Australia and New Zealand")]<-"Australia"
  #2.Europe
  db$continent[db$Region %in% c("Western Europe","Central and Eastern Europe")]<-"Europe"
  #3.Asia
  db$continent[db$Region %in% c("Southeastern Asia","Eastern Asia","Southern Asia")]<-"Asia"
  #4.North America
  db$continent[db$Region %in% c("North America")]<-"North America"
  #5.Africa
  db$continent[db$Region %in% c("Middle East and Northern Africa","Sub-Saharan Africa")]<-"Africa"
  #6.Southern America 
  db$continent[db$Region %in% c("Latin America and Caribbean")]<-"Sothern America"

#create the aggregate mean of the data for the visualization 
vb<-aggregate(db[,4:11],list(db$continent),mean)
View(vb)

--------------------------------------------------------------------------------------------------------------------------------------------
#step 2: data visualization
  
  #include all the libraries required for the visualization
  library(ggplot2)
  library(corrgram)
  library(corrplot)
  
  #summary of the data
  summarise(db)
  summary(db)  
  #view of top and bottom 10 data
  View(head(db,10))
  View(tail(db,10))
  #graph the mean of the data of all continents
  ggplot(vb,aes(x=Group.1,y=Happiness.Score,fill=Group.1))+geom_bar(stat = "identity")+ggtitle("happiness score of each continent")+xlab("continent")+ylab("happinessScore")
  #converting data into numeric for correlation
  col<-sapply(db,is.numeric)#is.numeric is a function which changes data into matrix or vector format
  cor.data<-cor(db[,col])#for checking the correlation ratio   